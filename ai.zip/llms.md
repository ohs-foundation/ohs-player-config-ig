# dev.ohs.ohs-player-config-ig#0.1.0: OHS Player Configuration IG

## Pages

* [Home](index.md)
* [Artifacts Summary](artifacts.md)

## Resources

### CodeSystems

* [Search Scope CodeSystem](CodeSystem-search-scope-cs.md)
* [UI Component Types (example)](CodeSystem-view-type-codesystem.md)

### ValueSets

* [Search Scope ValueSet](ValueSet-search-scope-vs.md)
* [View Type ValueSet](ValueSet-view-type-vs.md)

### Logicals

* [View Configuration](StructureDefinition-ViewConfig.md)
* [View Join Map](StructureDefinition-ViewJoinMap.md)

### ImplementationGuides

* [OHS Player Configuration IG](index.md)

### Examples

* [Allergy (Binary)](Binary-Allergy.md)
* [AllergyReaction (Binary)](Binary-AllergyReaction.md)
* [AllergyReactionState (Binary)](Binary-AllergyReactionState.md)
* [GroupCardConfigExample (Binary)](Binary-GroupCardConfigExample.md)
* [GroupMemberState (Binary)](Binary-GroupMemberState.md)
* [Member (Binary)](Binary-Member.md)
* [PatientAllergyState (Binary)](Binary-PatientAllergyState.md)
* [PatientContact (Binary)](Binary-PatientContact.md)
* [PatientContactState (Binary)](Binary-PatientContactState.md)
* [PatientHeaderConfigExample (Binary)](Binary-PatientHeaderConfigExample.md)
* [PatientSummary (Binary)](Binary-PatientSummary.md)
* [PatientSummaryState (Binary)](Binary-PatientSummaryState.md)
* [PatientTelecom (Binary)](Binary-PatientTelecom.md)
* [PatientTelecomState (Binary)](Binary-PatientTelecomState.md)
* [RelatedPerson (Binary)](Binary-RelatedPerson.md)
