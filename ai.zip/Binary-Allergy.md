# Allergy - OHS Player Configuration IG v0.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Allergy**

## Example Binary: Allergy

```

{
  "resourceType": "https://sql-on-fhir.org/ig/StructureDefinition/ViewDefinition",
  "fhirVersion": [
    "4.0.1"
  ],
  "select": [
    {
      "column": [
        {
          "name": "allergyId",
          "path": "id",
          "type": "http://hl7.org/fhir/StructureDefinition/string"
        },
        {
          "name": "substance",
          "path": "code.coding.display.first()",
          "type": "http://hl7.org/fhir/StructureDefinition/string"
        },
        {
          "name": "criticality",
          "path": "criticality",
          "type": "http://hl7.org/fhir/StructureDefinition/code"
        },
        {
          "name": "allergyStatus",
          "path": "clinicalStatus.coding.code.first()",
          "type": "http://hl7.org/fhir/StructureDefinition/string"
        },
        {
          "name": "allergyPatientRef",
          "path": "patient.reference.replace('Patient/', '')",
          "type": "http://hl7.org/fhir/StructureDefinition/string"
        }
      ]
    }
  ],
  "url": "http://ohs.dev/ViewDefinition/Allergy",
  "name": "Allergy",
  "status": "active",
  "resource": "AllergyIntolerance"
}

```



## Resource Binary Content

application/fhir+json:

```
{snip}
```
