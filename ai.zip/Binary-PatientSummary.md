# PatientSummary - OHS Player Configuration IG v0.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **PatientSummary**

## Binary: PatientSummary

```

{
  "resourceType": "https://sql-on-fhir.org/ig/StructureDefinition/ViewDefinition",
  "url": "http://ohs.dev/ViewDefinition/PatientSummary",
  "fhirVersion": [
    "4.0.1"
  ],
  "select": [
    {
      "column": [
        {
          "name": "patientId",
          "path": "id",
          "type": "http://hl7.org/fhir/StructureDefinition/string"
        },
        {
          "name": "familyName",
          "path": "name.family.first()",
          "type": "http://hl7.org/fhir/StructureDefinition/string"
        },
        {
          "name": "givenName",
          "path": "name.given.first()",
          "type": "http://hl7.org/fhir/StructureDefinition/string"
        },
        {
          "name": "gender",
          "path": "gender",
          "type": "http://hl7.org/fhir/StructureDefinition/code"
        },
        {
          "name": "birthDate",
          "path": "birthDate",
          "type": "http://hl7.org/fhir/StructureDefinition/date"
        },
        {
          "name": "active",
          "path": "active",
          "type": "http://hl7.org/fhir/StructureDefinition/boolean"
        },
        {
          "name": "mrn",
          "path": "identifier.where(type.coding.code = 'MR').value.first()",
          "type": "http://hl7.org/fhir/StructureDefinition/string"
        },
        {
          "name": "phone",
          "path": "telecom.where(system = 'phone').value.first()",
          "type": "http://hl7.org/fhir/StructureDefinition/string"
        }
      ]
    }
  ],
  "name": "PatientSummary",
  "status": "active",
  "resource": "Patient"
}

```



## Resource Binary Content

application/fhir+json:

```
{snip}
```
