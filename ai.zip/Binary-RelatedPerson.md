# RelatedPerson - OHS Player Configuration IG v0.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **RelatedPerson**

## Example Binary: RelatedPerson

```

{
  "resourceType": "https://sql-on-fhir.org/ig/StructureDefinition/ViewDefinition",
  "fhirVersion": [
    "4.0.1"
  ],
  "select": [
    {
      "column": [
        {
          "name": "relatedPersonId",
          "path": "id",
          "type": "http://hl7.org/fhir/StructureDefinition/string"
        },
        {
          "name": "headGivenName",
          "path": "name.given.first()",
          "type": "http://hl7.org/fhir/StructureDefinition/string"
        },
        {
          "name": "headFamilyName",
          "path": "name.family.first()",
          "type": "http://hl7.org/fhir/StructureDefinition/string"
        },
        {
          "name": "relationshipCode",
          "path": "relationship.coding.where(system = 'http://terminology.hl7.org/CodeSystem/v3-RoleCode').code.first()",
          "type": "http://hl7.org/fhir/StructureDefinition/code"
        },
        {
          "name": "relatedToPatientRef",
          "path": "patient.reference.replace('Patient/', '')",
          "type": "http://hl7.org/fhir/StructureDefinition/string"
        }
      ]
    }
  ],
  "url": "http://ohs.dev/ViewDefinition/RelatedPerson",
  "name": "RelatedPerson",
  "status": "active",
  "resource": "RelatedPerson"
}

```



## Resource Binary Content

application/fhir+json:

```
{snip}
```
