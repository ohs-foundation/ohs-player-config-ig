# AllergyReaction - OHS Player Configuration IG v0.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **AllergyReaction**

## Example Binary: AllergyReaction

```

{
  "resourceType": "https://sql-on-fhir.org/ig/StructureDefinition/ViewDefinition",
  "fhirVersion": [
    "4.0.1"
  ],
  "where": [
    {
      "path": "clinicalStatus.coding.where(system = 'http://terminology.hl7.org/CodeSystem/allergyintolerance-clinical').code = 'active'"
    }
  ],
  "select": [
    {
      "column": [
        {
          "name": "allergyId",
          "path": "id",
          "type": "http://hl7.org/fhir/StructureDefinition/string"
        },
        {
          "name": "substance",
          "path": "code.coding.display.first()",
          "type": "http://hl7.org/fhir/StructureDefinition/string"
        },
        {
          "name": "criticality",
          "path": "criticality",
          "type": "http://hl7.org/fhir/StructureDefinition/code"
        },
        {
          "name": "allergyPatientRef",
          "path": "patient.reference.replace('Patient/', '')",
          "type": "http://hl7.org/fhir/StructureDefinition/string"
        }
      ]
    },
    {
      "column": [
        {
          "name": "severity",
          "path": "severity",
          "type": "http://hl7.org/fhir/StructureDefinition/code"
        },
        {
          "name": "manifestation",
          "path": "manifestation.coding.display.first()",
          "type": "http://hl7.org/fhir/StructureDefinition/string"
        }
      ],
      "forEach": "reaction"
    }
  ],
  "url": "http://ohs.dev/ViewDefinition/AllergyReaction",
  "name": "AllergyReaction",
  "status": "active",
  "resource": "AllergyIntolerance"
}

```



## Resource Binary Content

application/fhir+json:

```
{snip}
```
